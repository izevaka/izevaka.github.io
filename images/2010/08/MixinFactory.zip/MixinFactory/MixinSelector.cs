﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.Core.Interceptor;

namespace MixinFactory {
	/// <summary>
	/// Matches interceptors that support can invoke the invoked method
	/// </summary>
	public class MixinSelector : IInterceptorSelector{
		#region IInterceptorSelector Members

		public IInterceptor[] SelectInterceptors(Type type, System.Reflection.MethodInfo method, IInterceptor[] interceptors) {
			var matched = interceptors
				.OfType<MixinInterceptor>()
				.Where(mi => method.DeclaringType.IsAssignableFrom(mi.ObjectType))
				.ToArray();
			if(matched.Length == 0)
				throw new InvalidOperationException("Cannot match method " + method.Name + "on type " + method.DeclaringType.FullName + ". No interceptor for this type is defined");
			return matched;
		}

		#endregion
	}
}
