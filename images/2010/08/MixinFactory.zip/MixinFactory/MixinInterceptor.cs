using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.Core.Interceptor;

namespace MixinFactory {
	public class MixinInterceptor : IInterceptor {
		private object m_Target;
		public MixinInterceptor(object invocationTarget) {
			if(invocationTarget == null) throw new System.ArgumentNullException("invocationTarget");
			this.m_Target = invocationTarget;
		}

		public Type ObjectType {
			get {
				return m_Target.GetType();
			}
		}

		#region IInterceptor Members

		[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1062:Validate arguments of public methods", MessageId = "0")]
		public void Intercept(IInvocation invocation) {
			IChangeProxyTarget changeTarget = (IChangeProxyTarget)invocation;
			changeTarget.ChangeInvocationTarget(m_Target);
			invocation.Proceed();
		}

		
		#endregion
	}
}
