﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.DynamicProxy;
//using Castle.Core.Interceptor;

namespace MixinFactory {


	public interface IEmptyInterface {
		
	}
    public static class Factory {
		/// <summary>
		/// Creates a mixin by comining all the interfaces implemented by objects array.
		/// </summary>
		/// <param name="instances">The objects to combine into one instance.</param>
		/// <returns>A dynamic proxy which delegates all calls on interfaces implemented by instances to those instances</returns>
		public static object CreateMixin(params object[] instances) {

			ProxyGenerator generator = new ProxyGenerator();
			ProxyGenerationOptions options = new ProxyGenerationOptions();

			instances.ToList().ForEach(obj => options.AddMixinInstance(obj));

			return generator.CreateClassProxy<object>(options);
		}

		/// <summary>
		/// Creates the mixin with specified target.
		/// </summary>
		/// <typeparam name="TIntf">The type of the interface to create.</typeparam>
		/// <param name="target">Target implementing the interface.</param>
		/// <param name="instances">The objects to combine into one instance.</param>
		/// <returns>A dynamic proxy that is based on target and which delegates all calls on interfaces implemented by instances to those instances</returns>
		public static TIntf CreateMixinWithTarget<TIntf>(TIntf target, params object[] instances) where TIntf : class{

			ProxyGenerator generator = new ProxyGenerator();
			ProxyGenerationOptions options = new ProxyGenerationOptions();

			instances.ToList().ForEach(obj => options.AddMixinInstance(obj));

			return generator.CreateInterfaceProxyWithTarget <TIntf>(target, options);
		}

		/// <summary>
		/// Creates a dynamic proxy of type TMixin. Members that called through this interface will be delegated to the first matched instance from the objects array
		/// It is up to the caller to make sure that objects parameter contains instances of all interfaces that TMixin implements
		/// </summary>
		/// <typeparam name="TMixin">The type of the mixin to return.</typeparam>
		/// <param name="instances">The objects that will be mixed in.</param>
		/// <returns>An instance of TMixin.</returns>
		public static TMixin CreateMixin<TMixin>(params object[] instances)
		where TMixin : class {
			if(instances == null || instances.Length == 0 || instances.Any(o => o == null))
				throw new ArgumentException("All mixins should be non-null", "instances");

			ProxyGenerator generator = new ProxyGenerator();
			ProxyGenerationOptions options = new ProxyGenerationOptions();
			options.Selector = new MixinSelector();
			var dummy = generator.CreateInterfaceProxyWithoutTarget<TMixin>();

			return generator.CreateInterfaceProxyWithTargetInterface<TMixin>(dummy, options, instances.Select(o => new MixinInterceptor(o)).ToArray());
		}
	}
}
