﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Reflection;
using Castle.Core.Interceptor;
using MixinFactory;


namespace MixinFactory.Test
{
    [TestClass()]
	public class MixinSelectorTest {

		[TestMethod()]
		public void SelectInterceptorsShouldMatchType() {
			MixinSelector target = new MixinSelector(); 
			Type type = typeof(ICat);

			ICat cat = new Cat();
			IDog dog = new Dog();
			var catInterceptor = new MixinInterceptor(cat);
			IInterceptor[] interceptors = new[] {catInterceptor , new MixinInterceptor(dog) };
			IInterceptor[] expected = new []{ catInterceptor }; 
			IInterceptor[] actual;
			actual = target.SelectInterceptors(type, type.GetMethod("Meow"), interceptors);
			CollectionAssert.AreEquivalent(expected, actual);
		}

		[TestMethod]
		public void MixinSelectorShouldThrowWhenCantMatch() {
			MixinSelector target = new MixinSelector();
			Type type = typeof(ICat);


			IInterceptor[] interceptors = new[] { new MixinInterceptor(new Dog()), new MixinInterceptor(new Mouse()) };
			IInterceptor[] actual;
			try {
				actual = target.SelectInterceptors(null, type.GetMethod("Meow"), interceptors);
			} catch(InvalidOperationException) {
				return;
			}

			Assert.Fail("Expected InvalidOperationException");

		}
	}
}
