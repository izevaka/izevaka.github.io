﻿using MixinFactory;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Castle.Core.Interceptor;
using Moq;

namespace MixinFactory.Test
{
    [TestClass()]
	public class MixinInterceptorTest {

		[TestMethod()]
		[ExpectedException(typeof(ArgumentNullException))]
		public void ConstructorShouldThrowOnNullParam() {
			object invocationTarget = null; 
			MixinInterceptor target = new MixinInterceptor(invocationTarget);
		}

		[TestMethod()]
		public void InterceptShouldChangeInvocationTarget() {
			object invocationTarget = "test"; 
			MixinInterceptor target = new MixinInterceptor(invocationTarget); 
			var invocationMock = new Mock<IInvocationChangeProxy>(); 
			
			target.Intercept(invocationMock.Object);
			invocationMock.Verify(i => i.ChangeInvocationTarget(invocationTarget));
			invocationMock.Verify(i => i.Proceed());
		}

		[TestMethod()]
		public void ObjectTypeShouldReturnParameterType() {
			object invocationTarget = "test"; 
			MixinInterceptor target = new MixinInterceptor(invocationTarget); 
			Type actual;
			actual = target.ObjectType;
			Assert.AreEqual(typeof(string), actual);
		}
	}

	public interface IInvocationChangeProxy :IInvocation, IChangeProxyTarget {
		
	}
}
