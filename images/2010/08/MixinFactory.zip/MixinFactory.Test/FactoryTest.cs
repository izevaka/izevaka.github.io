﻿using MixinFactory;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics;

namespace MixinFactory.Test {

	[TestClass()]
	public class FactoryTest {

		[TestMethod]
		public void CreatedMixinShouldntThrow() {
			ICat obj1 = new Cat();
			IDog obj2 = new Dog();

			var actual = Factory.CreateMixin(obj1, obj2);
			((IDog)actual).Bark();
			var weight = ((IDog)actual).Weight;
			((ICat)actual).Meow();
			var age = ((ICat)actual).Age;
		}

		[TestMethod]
		public void CreatedGeneric3MixinShouldntThrow() {
			ICat obj1 = new Cat();
			IDog obj2 = new Dog();
			IMouse obj3 = new Mouse();
			var actual = Factory.CreateMixin<ICatDogMouse>(obj1, obj2, obj3);

			actual.Bark();
			var weight = actual.Weight;
			actual.Meow();
			var age = actual.Age;
			actual.Squeek();
		}

		[TestMethod]
		[ExpectedException(typeof(ArgumentException))]
		public void GenericMixinShouldThrowOnNull() {
			ICat obj1 = new Cat();
			var actual = Factory.CreateMixin<ICatDog>(obj1, null);
		}
		[TestMethod]
		[ExpectedException(typeof(ArgumentException))]
		public void GenericMixinShouldThrowOnNoParams() {
			ICat obj1 = new Cat();
			var actual = Factory.CreateMixin<ICatDog>();
		}

		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException))]
		public void GenericMixingShouldThrowIfUnderspecified() {
			var actual = Factory.CreateMixin<ICatDogMouse>(new Cat(), new Dog());
			actual.Squeek();
		}

		[TestMethod]
		public void CreatedMixinWithTargetShouldPreserveObject() {
			Cat obj1 = new Cat();
			IDog obj2 = new Dog();

			obj1.Age = 7;
			var actual = Factory.CreateMixinWithTarget<ICat>(obj1, obj2);
			Assert.AreEqual(17, ((Cat)actual).Age);
			((IDog)actual).Bark();
		}
	}
}
