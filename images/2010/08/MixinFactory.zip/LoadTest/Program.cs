﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using MixinFactory;
using MixinFactory.Test;

namespace LoadTest {

	class CatDog : ICat, IDog {
		#region IDog Members

		public void Bark() {
			
		}

		public int Weight {
			get {
				throw new NotImplementedException();
			}
			set {
				throw new NotImplementedException();
			}
		}

		#endregion

		#region ICat Members

		public void Meow() {
			throw new NotImplementedException();
		}

		public int Age {
			get {
				throw new NotImplementedException();
			}
			set {
				throw new NotImplementedException();
			}
		}

		#endregion
	}


	class Program {
		static void Main(string[] args) {
			Stopwatch stopwatch = new Stopwatch();
			var genericCatDog = Factory.CreateMixin<ICatDog>(new Cat(), new Dog());
			var normalCatDog = Factory.CreateMixin(new Cat(), new Dog());

			stopwatch.Start();
			int count = 8000000;
			for(int i = 0; i < count; i++) {
				genericCatDog.Bark();
			}
			stopwatch.Stop();

			Console.WriteLine("Generic performance " + stopwatch.ElapsedMilliseconds);

			stopwatch.Reset();
			stopwatch.Start();
			IDog iDog = (IDog)normalCatDog;
			for(int i = 0; i < count; i++) {
				iDog.Bark();
			}
			stopwatch.Stop();


			Console.WriteLine("Mixin performance " + stopwatch.ElapsedMilliseconds);

			stopwatch.Reset();
			stopwatch.Start();
			iDog = new CatDog();
			for(int i = 0; i < count; i++) {
				iDog.Bark();
			}
			stopwatch.Stop();


			Console.WriteLine("Native performance " + stopwatch.ElapsedMilliseconds);

		}
	}
}
